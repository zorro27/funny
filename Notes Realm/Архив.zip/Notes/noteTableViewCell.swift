//
//  noteTableViewCell.swift
//  Notes
//
//  Created by Роман Зобнин on 15.03.2021.
//

import UIKit

class noteTableViewCell: UITableViewCell {

    @IBOutlet weak var nameNoteLabel: UILabel!
    @IBOutlet weak var deleteButton: UIButton!
}
