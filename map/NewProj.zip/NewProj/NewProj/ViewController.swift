//
//  ViewController.swift
//  NewProj
//
//  Created by Роман Зобнин on 25.02.2021.
//

import UIKit
import Alamofire

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

