//
//  loadJson.swift
//  searchGit
//
//  Created by Роман Зобнин on 05.03.2021.
//

import Foundation

var nameUser = ""

protocol usersDelegate {
    func saveUsers (array: [User])
}

var api: String = "https://api.github.com/search/users?q=" + nameUser

class loadUser {
    
    var delegate: usersDelegate?
    
    func load () {
        let urlString = URL(string: api)!
        let request = URLRequest(url: urlString)
        let task = URLSession.shared.dataTask(with: request) {(data, responce, error) in
            if let data = data,
            let json = try? JSONSerialization.jsonObject(with: data, options: .allowFragments),
            let jsonDict = json as? NSDictionary {
                let a = pars(json: jsonDict as NSDictionary)
                DispatchQueue.main.async {
                    self.delegate?.saveUsers(array: a)
                    print (a.count)
                }
            }
            }
        task.resume()
        print (nameUser)
    }
}
