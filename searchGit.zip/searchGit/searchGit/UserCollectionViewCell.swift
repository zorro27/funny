//
//  UserCollectionViewCell.swift
//  searchGit
//
//  Created by Роман Зобнин on 08.03.2021.
//

import UIKit

class UserCollectionViewCell: UICollectionViewCell {
    
}
