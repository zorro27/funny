//
//  MyCollectionViewCell.swift
//  searchGit
//
//  Created by Роман Зобнин on 05.03.2021.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var avatarUser: UIImageView!
    @IBOutlet weak var nameUser: UILabel!
    @IBOutlet weak var urlUser: UILabel!
    
}
