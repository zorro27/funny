//
//  UserTableViewCell.swift
//  searchGit
//
//  Created by Роман Зобнин on 08.03.2021.
//

import UIKit

class UserTableViewCell: UITableViewCell {
    @IBOutlet weak var ava: UIImageView!
    @IBOutlet weak var twoLabel: UILabel!
    @IBOutlet weak var threeLabel: UILabel!
}
