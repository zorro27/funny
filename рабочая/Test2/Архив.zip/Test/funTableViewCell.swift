//
//  funTableViewCell.swift
//  Test
//
//  Created by Роман Зобнин on 24.01.2021.
//

import UIKit

class funTableViewCell: UITableViewCell {

    @IBOutlet weak var funLabel: UILabel!
    
}
